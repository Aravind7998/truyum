CREATE DATABASE truYum;
USE truYum;

CREATE TABLE menu_items(
ID INT AUTO_INCREMENT PRIMARY KEY,
Name VARCHAR(20),
Price DECIMAL(8,2),
Active VARCHAR(4),
Date_Of_Launch DATE,
Category VARCHAR(20),
Free_delivery VARCHAR(5)
);
Create table users(
userid INT AUTO_INCREMENT PRIMARY KEY,
userName VARCHAR(20)
);
Create table cart(
cart_id INT AUTO_INCREMENT PRIMARY KEY,
userid INT,
ID INT,
CONSTRAINT Fkey1 FOREIGN KEY (userid) REFERENCES users(userid),
CONSTRAINT Fkey2 FOREIGN KEY (ID) REFERENCES menu_items(ID)
);
-- TYUC001
INSERT INTO menu_items(Name,Price,Active,Date_Of_launch,Category,Free_delivery)
VALUES('Sandwich','99.00','Yes','2017-03-15','Main course','Yes'),
('Burger','129.00','Yes','2017-12-23','Main course','Yes'),
('Pizza','149.00','Yes','2017-08-21','Main course','No'),
('French Fries','57.00','No','2017-07-02','Starters','No'),
('Chocolate Brownie','32.00','Yes','2022-11-02','Dessert','Yes');
 
SELECT Name,concat('Rs. ',Price) as 'Price',
Active,Date_Of_Launch,Category,Free_Delivery FROM menu_items;


-- TYUC002

SELECT Name,concat('Rs. ',Price) as 'Price',
Category,Free_delivery FROM menu_items
WHERE Active = 'Yes' and Date_Of_launch <= curdate();

--  TYUC003
SET @ID = 2;
SELECT Name,concat('Rs. ',Price) as 'Price',
Active,Date_Of_Launch,Category,Free_Delivery FROM menu_items WHERE ID = @ID;

update menu_items
SET Price='100.00'
WHERE ID= @ID;

--  TYUC004
INSERT INTO users(userName)
VALUES('Abhi'),
('Dev');
INSERT INTO cart(user_id,ID) VALUES(2,4),(2,1),(2,3);

--  TYUC005
SET @userid = 2;
 SELECT Name,concat('Rs. ',Price) as 'Price',
 Category,Free_Delivery FROM menu_items m
 INNER JOIN cart c
 on m.ID = c.ID
 INNER JOIN users u
 on u.user_id = c.user_id
 WHERE u.user_id = @user_id;
 
 SET @user_id = 2;
 SELECT sum(Price) as Total_price
 FROM menu_items m 
 INNER JOIN cart c
 ON m.ID = c.ID
 INNER JOIN users u
 ON u.userid = c.userid
 WHERE u.userid = @userid;
 
 -- TYUC006
 SET @userid = 2;
 SET @ID = 4;
 delete FROM cart 
WHERE ID = @ID and userid = @userid;
 

 
 
 


